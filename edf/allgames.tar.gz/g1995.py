from game import Game 

g1995 = []

# 
g = Game('18 Jan 1995','netherlands','f','away',1,0)
g.players = ['lama','karembeu','blanc','desailly','dimeco','ferri',
             'cantona','leguen','pedros','loko','papin']
g.subs = ['angloma','ouedec']
g1995.append(g)

# 
g = Game('29 Mar 1995','israel','eq','away',0,0)
g.players = ['lama','angloma','blanc','roche','dimeco','desailly',
             'martins','leguen','pedros','loko','ouedec']
g.subs = ['djorkaeff','ginola']
g1995.append(g)

# 
g = Game('26 Apr 1995','slovakia','eq','home',4,0)
g.players = ['lama','angloma','blanc','roche','dimeco','deschamps',
             'desailly','zidane','guerin','loko','ginola']
g.subs = ['djorkaeff']
g1995.append(g)

# 
g = Game('22 Jul 1995','norway','f','away',0,0)
g.players = ['lama','thuram','blanc','roche','lizarazu','makelele',
             'zidane','leguen','guerin','cocard','pedros']
g.subs = ['djorkaeff','leboeuf','martins']
g1995.append(g)

# 
g = Game('16 Aug 1995','poland','eq','home',1,1)
g.players = ['lama','angloma','thuram','leboeuf','lizarazu','deschamps',
             'desailly','zidane','guerin','dugarry','ginola']
g.subs = ['karembeu','djorkaeff','pedros']
g1995.append(g)

# 
g = Game('6 Sep 1995','azerbaijan','eq','home',10,0)
g.players = ['lama','angloma','leboeuf','desailly','lizarazu','guerin',
             'zidane','deschamps','pedros','djorkaeff','dugarry']
g.subs = ['thuram','ginola','cocard']
g1995.append(g)

# 
g = Game('11 Oct 1995','romania','eq','away',3,1)
g.players = ['barthez','angloma','leboeuf','desailly','dimeco','karembeu',
             'deschamps','zidane','guerin','djorkaeff','dugarry']
g.subs = ['thuram','lizarazu','madar']
g1995.append(g)

# 
g = Game('15 Nov 1995','israel','eq','home',2,0)
g.players = ['lama','angloma','leboeuf','desailly','dimeco','karembeu',
             'zidane','deschamps','guerin','djorkaeff','madar']
g.subs = ['lizarazu','keller','loko']
g1995.append(g)

