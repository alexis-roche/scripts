from game import Game 

g1994 = []

# 
g = Game('16 Feb 1994','italy','f','away',1,0)
g.players = ['lama','karembeu','roche','desailly','dimeco','gnako',
             'deschamps','djorkaeff','leguen','cantona','ginola']
g.subs = ['cyprien','martins','guerin']
g1994.append(g)

# 
g = Game('22 Mar 1994','chile','f','home',3,1)
g.players = ['lama','angloma','roche','desailly','lizarazu','deschamps',
             'djorkaeff','ferri','cocard','papin','ginola']
g.subs = ['leguen','karembeu','martins','vahirua']
g1994.append(g)

# 
g = Game('25 May 1994','australia','f','neutral',1,0)
g.players = ['barthez','karembeu','angloma','blanc','dimeco','petit',
             'ferri','cantona','dugarry','papin','ginola']
g.subs = ['martins','pedros']
g1994.append(g)

# 
g = Game('29 May 1994','japan','f','neutral',4,1)
g.players = ['lama','angloma','blanc','desailly','dimeco','djorkaeff',
             'deschamps','leguen','cantona','papin','ginola']
g.subs = ['karembeu','lizarazu','ouedec']
g1994.append(g)

# 
g = Game('17 Aug 1994','czech republic','f','home',2,2)
g.players = ['lama','angloma','thuram','blanc','ngotty','dimeco',
             'desailly','cantona','martins','dugarry','ginola']
g.subs = ['ferri','zidane','loko','lizarazu']
g1994.append(g)

# 
g = Game('7 Sep 1994','slovakia','eq','away',0,0)
g.players = ['lama','angloma','blanc','roche','dimeco','djorkaeff',
             'deschamps','leguen','pedros','cantona','ginola']
g.subs = ['lizarazu','dugarry']
g1994.append(g)

# 
g = Game('8 Oct 1994','romania','eq','home',0,0)
g.players = ['lama','angloma','blanc','roche','lizarazu','karembeu',
             'cantona','desailly','pedros','ouedec','loko']
g.subs = ['dugarry','zidane']
g1994.append(g)


# 
g = Game('16 Nov 1994','poland','eq','away',0,0)
g.players = ['lama','angloma','blanc','roche','dimeco','karembeu',
             'desailly','pedros','leguen','cantona','ouedec']
g.subs = ['djorkaeff','dugarry']
g1994.append(g)

# 
g = Game('13 Dec 1994','azerbaijan','eq','away',2,0)
g.players = ['lama','angloma','blanc','roche','dimeco','desailly',
             'leguen','pedros','loko','papin','cantona']
g.subs = ['ferri','martins']
g1994.append(g)

