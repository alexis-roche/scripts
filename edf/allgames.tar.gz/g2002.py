from game import Game 

g2002 = []

# 
g = Game('13 Feb 2002','romania','f','home',2,1)
g.players = ['rame','thuram','desailly','christanval','candela','vieira',
             'petit','zidane','pires','henry','dugarry']
g.subs = ['boghossian','makelele','carriere','trezeguet','wiltord']
g2002.append(g)

# 
g = Game('27 Mar 2002','scotland','f','home',5,0)
g.players = ['barthez','candela','desailly','leboeuf','lizarazu','vieira',
             'petit','zidane','wiltord','henry','trezeguet']
g.subs = ['karembeu','silvestre','christanval','makelele','djorkaeff','marlet','carriere']
g2002.append(g)

# 
g = Game('17 Apr 2002','russia','f','home',0,0)
g.players = ['barthez','thuram','desailly','leboeuf','lizarazu','vieira',
             'petit','zidane','djorkaeff','henry','anelka']
g.subs = ['candela','boghossian','marlet','micoud']
g2002.append(g)

# 
g = Game('18 May 2002','belgium','f','home',1,2)
g.players = ['rame','thuram','desailly','leboeuf','lizarazu','vieira',
             'petit','wiltord','djorkaeff','dugarry','trezeguet']
g.subs = ['sagnol','candela','boghossian','micoud','cisse']
g2002.append(g)

# 
g = Game('26 May 2002','south korea','f','away',3,2)
g.players = ['barthez','thuram','desailly','leboeuf','lizarazu','vieira',
             'petit','zidane','djorkaeff','henry','trezeguet']
g.subs = ['candela','silvestre','sagnol','makelele','cisse','wiltord','dugarry']
g2002.append(g)

# 
g = Game('31 May 2002','senegal','w','neutral',0,1)
g.players = ['barthez','thuram','desailly','leboeuf','lizarazu','vieira',
             'petit','wiltord','djorkaeff','henry','trezeguet']
g.subs = ['cisse','dugarry']
g2002.append(g)

# 
g = Game('6 Jun 2002','uruguay','w','neutral',0,0)
g.players = ['barthez','thuram','desailly','leboeuf','lizarazu','vieira',
             'petit','wiltord','micoud','henry','trezeguet']
g.subs = ['candela','cisse','dugarry']
g2002.append(g)

# 
g = Game('11 Jun 2002','denmark','w','neutral',0,2)
g.players = ['barthez','thuram','desailly','candela','lizarazu','vieira',
             'makelele','wiltord','zidane','dugarry','trezeguet']
g.subs = ['micoud','djorkaeff','cisse']
g2002.append(g)

# 
g = Game('21 Aug 2002','tunisia','f','away',1,1)
g.players = ['coupet','thuram','silvestre','christanval','sagnol','makelele',
             'carriere','candela','zidane','henry','govou']
g.subs = ['cheyrou','desailly','vieira','petit','brechet','marlet','cisse']
g2002.append(g)

# 
g = Game('7 Sep 2002','cyprus','eq','away',2,1)
g.players = ['coupet','thuram','silvestre','christanval','desailly','makelele',
             'vieira','zidane','marlet','wiltord','cisse']
g.subs = ['govou','kapo']
g2002.append(g)

# 
g = Game('12 Oct 2002','slovenia','eq','home',5,0)
g.players = ['barthez','thuram','silvestre','gallas','desailly','vieira',
             'makelele','zidane','marlet','wiltord','henry']
g.subs = ['cheyrou','sagnol','govou']
g2002.append(g)

# 
g = Game('16 Oct 2002','malta','eq','away',4,0)
g.players = ['barthez','thuram','silvestre','gallas','desailly','vieira',
             'makelele','zidane','marlet','wiltord','henry']
g.subs = ['mexes','dacourt','carriere']
g2002.append(g)

# 
g = Game('20 Nov 2002','yougoslavia','f','home',3,0)
g.players = ['barthez','thuram','brechet','gallas','desailly','petit',
             'makelele','carriere','kapo','marlet','henry']
g.subs = ['pedretti','mexes','silvestre','wiltord','giuly','moreira']
g2002.append(g)

