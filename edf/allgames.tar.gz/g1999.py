from game import Game 

g1999 = []

# 
g = Game('20 Jan 1999','morocco','f','home',1,0)
g.players = ['barthez','thuram','blanc','desailly','candela','deschamps',
             'zidane','boghossian','djorkaeff','maurice','dugarry']
g.subs = ['leboeuf','petit','anelka','pires']
g1999.append(g)


# 
g = Game('10 Feb 1999','england','f','away',2,0)
g.players = ['barthez','thuram','blanc','desailly','lizarazu','deschamps',
             'pires','zidane','petit','djorkaeff','anelka']
g.subs = ['leboeuf','dugarry','candela','vieira','wiltord']
g1999.append(g)

# 
g = Game('27 Mar 1999','ukraine','eq','home',0,0)
g.players = ['barthez','thuram','blanc','desailly','lizarazu','deschamps',
             'pires','petit','djorkaeff','dugarry','anelka']
g.subs = ['boghossian','dhorasoo','wiltord']
g1999.append(g)

# 
g = Game('31 Mar 1999','armenia','eq','home',2,0)
g.players = ['barthez','thuram','blanc','desailly','boghossian','deschamps',
             'djorkaeff','vieira','wiltord','dugarry','anelka']
g.subs = ['karembeu','pires','trezeguet']
g1999.append(g)

# 
g = Game('5 Jun 1996','russia','eq','home',2,3)
g.players = ['barthez','thuram','blanc','desailly','candela','deschamps',
             'djorkaeff','petit','wiltord','dugarry','anelka']
g.subs = ['pires','boghossian','vieira']
g1999.append(g)

# 
g = Game('9 Jun 1996','andorra','eq','away',1,0)
g.players = ['rame','karembeu','leboeuf','desailly','candela','boghossian',
             'petit','dhorasoo','wiltord','dugarry','anelka']
g.subs = ['pires','vieira']
g1999.append(g)

# 
g = Game('18 Aug 1999','nothern ireland','f','away',1,0)
g.players = ['barthez','thuram','blanc','desailly','lizarazu','pires',
             'vieira','boghossian','micoud','wiltord','laslandes']
g.subs = ['leboeuf','candela','dehu','robert','vairelles']
g1999.append(g)

# 
g = Game('4 Sep 1999','ukraine','eq','away',0,0)
g.players = ['barthez','thuram','blanc','desailly','lizarazu','karembeu',
             'deschamps','zidane','vieira','djorkaeff','anelka']
g.subs = ['pires','laslandes']
g1999.append(g)

# 
g = Game('8 Sep 1999','armenia','eq','away',3,2)
g.players = ['barthez','thuram','blanc','desailly','lizarazu','karembeu',
             'deschamps','zidane','djorkaeff','laslandes','wiltord']
g.subs = ['dehu','robert']
g1999.append(g)

# 
g = Game('9 Oct 1999','iceland','eq','home',3,2)
g.players = ['barthez','thuram','blanc','desailly','lizarazu','boghossian',
             'deschamps','zidane','djorkaeff','laslandes','wiltord']
g.subs = ['vieira','vairelles','trezeguet']
g1999.append(g)

# 
g = Game('13 Nov 1999','croatia','f','home',3,0)
g.players = ['porato','thuram','leboeuf','desailly','candela','boghossian',
             'vieira','zidane','micoud','pires','guivarch']
g.subs = ['djorkaeff','dehu','deschamps','vairelles','maurice']
g1999.append(g)

