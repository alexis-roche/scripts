from game import Game 

g1996 = []

# 
g = Game('24 Jan 1996','portugal','f','home',3,2)
g.players = ['lama','angloma','leboeuf','desailly','dimeco','karembeu',
             'deschamps','zidane','guerin','djorkaeff','loko']
g.subs = ['lamouchi','pedros','pouget']
g1996.append(g)

# 
g = Game('21 Feb 1996','greece','f','home',3,1)
g.players = ['lama','angloma','thuram','desailly','petit','deschamps',
             'djorkaeff','karembeu','pedros','lamouchi','loko']
g.subs = ['leboeuf','pouget','zidane','laigle']
g1996.append(g)

# 
g = Game('27 Mar 1996','belgium','f','away',2,0)
g.players = ['lama','thuram','blanc','roche','dimeco','karembeu',
             'martins','deschamps','pedros','lamouchi','dugarry']
g.subs = ['angloma','laigle','pouget']
g1996.append(g)

# 
g = Game('29 May 1996','finland','f','home',2,0)
g.players = ['martini','angloma','thuram','leboeuf','dimeco','desailly',
             'martins','guerin','pedros','lamouchi','loko']
g.subs = ['lizarazu','karembeu','dugarry']
g1996.append(g)

# 
g = Game('1 Jun 1996','germany','f','away',1,0)
g.players = ['lama','thuram','blanc','desailly','dimeco','karembeu',
             'deschamps','zidane','guerin','djorkaeff','dugarry']
g.subs = ['lizarazu','angloma','loko','lamouchi','pedros']
g1996.append(g)

# 
g = Game('5 Jun 1996','armenia','f','home',2,0)
g.players = ['lama','angloma','blanc','desailly','lizarazu','deschamps',
             'zidane','guerin','lamouchi','madar','djorkaeff']
g.subs = ['thuram','karembeu','loko']
g1996.append(g)

# 
g = Game('10 Jun 1996','romania','e','neutral',1,0)
g.players = ['lama','thuram','blanc','desailly','dimeco','karembeu',
             'deschamps','zidane','guerin','djorkaeff','dugarry']
g.subs = ['lizarazu','roche','loko']
g1996.append(g)

# 
g = Game('15 Jun 1996','spain','e','neutral',1,1)
g.players = ['lama','angloma','blanc','desailly','lizarazu','karembeu',
             'deschamps','zidane','guerin','djorkaeff','loko']
g.subs = ['roche','thuram','dugarry']
g1996.append(g)

# 
g = Game('18 Jun 1996','bulgaria','e','neutral',3,1)
g.players = ['lama','thuram','blanc','desailly','lizarazu','karembeu',
             'deschamps','zidane','guerin','djorkaeff','dugarry']
g.subs = ['pedros','loko']
g1996.append(g)

# 
g = Game('22 Jun 1996','netherlands','e','neutral',0,0)
g.players = ['lama','thuram','blanc','desailly','lizarazu','karembeu',
             'zidane','deschamps','guerin','djorkaeff','loko']
g.subs = ['dugarry','pedros']
g1996.append(g)

# 
g = Game('26 Jun 1996','czech republic','e','neutral',0,0)
g.players = ['lama','thuram','blanc','roche','lizarazu','lamouchi',
             'desailly','zidane','guerin','loko','djorkaeff']
g.subs = ['angloma','pedros']
g1996.append(g)

# 
g = Game('31 Aug 1996','mexico','f','home',2,0)
g.players = ['lama','thuram','blanc','desailly','lizarazu','karembeu',
             'djorkaeff','deschamps','pedros','loko','ouedec']
g.subs = ['lamouchi','leboeuf','zidane','pires','maurice']
g1996.append(g)

# 
g = Game('9 Oct 1996','turkey','f','home',4,0)
g.players = ['barthez','karembeu','blanc','goma','thuram','lamouchi',
             'zidane','deschamps','pedros','loko','djorkaeff']
g.subs = ['djetou','candela','gava','pires']
g1996.append(g)

# 
g = Game('9 Nov 1996','denmark','f','away',0,1)
g.players = ['barthez','thuram','ngotty','desailly','candela','martins',
             'karembeu','deschamps','zidane','djorkaeff','pedros']
g.subs = ['laigle','loko','keller','pires']
g1996.append(g)


