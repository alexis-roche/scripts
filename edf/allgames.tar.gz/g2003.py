from game import Game 

g2003 = []

# 
g = Game('12 Feb 2003','czech repuclic','f','home',0,2)
g.players = ['rame','thuram','desailly','gallas','lizarazu','makelele',
             'petit','zidane','wiltord','marlet','henry']
g.subs = ['silvestre','vieira','pedretti','pires','trezeguet','cisse']
g2003.append(g)

# 
g = Game('29 Mar 2003','malta','eq','home',6,0)
g.players = ['barthez','thuram','silvestre','gallas','lizarazu','makelele',
             'pedretti','zidane','wiltord','trezeguet','henry']
g.subs = ['sagnol','govou','rothen']
g2003.append(g)

# 
g = Game('2 Apr 2003','israel','eq','away',2,1)
g.players = ['barthez','thuram','silvestre','gallas','lizarazu','makelele',
             'vieira','zidane','wiltord','trezeguet','henry']
g.subs = ['govou','rothen']
g2003.append(g)

# 
g = Game('30 Apr 2003','egypt','f','home',5,0)
g.players = ['barthez','sagnol','desailly','gallas','lizarazu','dacourt',
             'pedretti','pires','wiltord','cisse','henry']
g.subs = ['rothen','mexes','silvestre','moreira','kapo']
g2003.append(g)

# 
g = Game('18 Jun 2003','colombia','c','home',1,0)
g.players = ['coupet','thuram','desailly','mexes','lizarazu','dacourt',
             'pedretti','kapo','wiltord','cisse','henry']
g.subs = ['pires','govou','marlet']
g2003.append(g)

# 
g = Game('20 Jun 2003','japan','c','home',2,1)
g.players = ['barthez','sagnol','boumsong','gallas','silvestre','dacourt',
             'dabo','rothen','govou','pires','marlet']
g.subs = ['pedretti','wiltord','henry']
g2003.append(g)

# 
g = Game('22 Jun 2003','new zealand','c','home',5,0)
g.players = ['landreau','thuram','desailly','mexes','lizarazu','pedretti',
             'kapo','giuly','wiltord','henry','cisse']
g.subs = ['pires','dabo','marlet']
g2003.append(g)

# 
g = Game('26 Jun 2003','turkey','c','home',3,2)
g.players = ['coupet','thuram','desailly','gallas','silvestre','dacourt',
             'pedretti','govou','pires','wiltord','henry']
g.subs = ['kapo','giuly','cisse']
g2003.append(g)

# 
g = Game('29 Jun 2003','cameroon','c','home',1,0)
g.players = ['barthez','sagnol','desailly','gallas','lizarazu','dacourt',
             'pedretti','giuly','cisse','wiltord','henry']
g.subs = ['thuram','kapo','pires']
g2003.append(g)

# 
g = Game('20 Aug 2003','switzerland','f','away',2,0)
g.players = ['barthez','thuram','desailly','silvestre','lizarazu','dacourt',
             'vieira','zidane','wiltord','henry','trezeguet']
g.subs = ['sagnol','boumsong','cisse','pedretti','dabo','giuly','pires','marlet']
g2003.append(g)

# 
g = Game('6 Sep 2003','cyprus','eq','home',5,0)
g.players = ['barthez','thuram','desailly','silvestre','lizarazu','makelele',
             'vieira','pires','wiltord','henry','trezeguet']
g.subs = ['sagnol','dacourt','marlet']
g2003.append(g)

# 
g = Game('10 Sep 2003','slovenia','eq','away',2,0)
g.players = ['barthez','thuram','desailly','silvestre','lizarazu','makelele',
             'vieira','zidane','wiltord','henry','trezeguet']
g.subs = ['sagnol','pires','dacourt']
g2003.append(g)

# 
g = Game('11 Oct 2003','israel','eq','home',3,0)
g.players = ['barthez','thuram','boumsong','reveillere','lizarazu','dacourt',
             'pedretti','zidane','pires','henry','trezeguet']
g.subs = ['giuly','marlet','cisse']
g2003.append(g)

# 
g = Game('15 Oct 2003','germany','f','away',3,0)
g.players = ['coupet','sagnol','thuram','silvestre','lizarazu','dacourt',
             'makelele','zidane','pires','henry','trezeguet']
g.subs = ['gallas','wiltord','govou']
g2003.append(g)

