from game import Game 

g1997 = []

# 
g = Game('22 Jan 1997','portugal','f','away',2,0)
g.players = ['barthez','thuram','blanc','desailly','laigle','karembeu',
             'deschamps','zidane','ba','dugarry','pires']
g.subs = ['ngotty','djorkaeff','loko','blondeau']
g1997.append(g)

# 
g = Game('26 Feb 1997','netherlands','f','home',2,1)
g.players = ['lama','thuram','blanc','desailly','lizarazu','karembeu',
             'vieira','zidane','laigle','ba','dugarry']
g.subs = ['candela','ngotty','pires','loko']
g1997.append(g)

# 
g = Game('2 Apr 1997','sweden','f','home',1,0)
g.players = ['barthez','thuram','blanc','desailly','candela','ba',
             'makelele','zidane','vieira','djorkaeff','dugarry']
g.subs = ['blondeau','keller','gava','djetou','loko']
g1997.append(g)

# 
g = Game('3 Jun 1997','brazil','f','home',1,1)
g.players = ['barthez','candela','blanc','desailly','lizarazu','karembeu',
             'deschamps','zidane','ba','maurice','pires']
g.subs = ['thuram','vieira','keller']
g1997.append(g)

# 
g = Game('7 Jun 1997','england','f','home',0,1)
g.players = ['barthez','thuram','blanc','ngotty','laigle','djorkaeff',
             'vieira','deschamps','dugarry','ouedec','keller']
g.subs = ['lizarazu','zidane','loko']
g1997.append(g)

# 
g = Game('11 Jun 1997','italy','f','home',2,2)
g.players = ['charbonnier','thuram','leboeuf','desailly','lizarazu','ba',
             'karembeu','zidane','deschamps','dugarry','maurice']
g.subs = ['ngotty','vieira','djorkaeff']
g1997.append(g)

# 
g = Game('11 Oct 1997','south africa','f','home',2,1)
g.players = ['letizi','thuram','blanc','desailly','candela','deschamps',
             'djorkaeff','petit','pires','guivarch','henry']
g.subs = ['laigle','ba','boghossian','zidane']
g1997.append(g)

# 
g = Game('12 Nov 1997','scotland','f','home',2,1)
g.players = ['barthez','thuram','blanc','desailly','laigle','ba',
             'deschamps','zidane','petit','laslandes','guivarch']
g.subs = ['candela','gava','boghossian','djorkaeff']
g1997.append(g)
